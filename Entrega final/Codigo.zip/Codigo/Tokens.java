package code;

public enum Tokens {
    Pal_Res,
    opAsignacion,
    opAutodecremento,
    suma,
    negacion,
    mayor,
    puntoComa,
    coma,
    cadena,
    id,
    entero,
    dosPuntos,
    parentesisAbierto,
    parentesisCerrado,
    llaveAbierta,
    llaveCerrada,
    ERROR;
}
