package code;

public enum Tipo {
	INT, BOOLEAN, STRING, FUNCTION, VACIO
}
